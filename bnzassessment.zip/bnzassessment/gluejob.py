import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import awswrangler as wr
import boto3
import json

# Get Job Arguments
args = getResolvedOptions(sys.argv, ['secret_id'])


customer = glueContext.create_dynamic_frame.from_catalog(database="bnzanalyticsdb", table_name="customer")
account = glueContext.create_dynamic_frame.from_catalog(database="bnzanalyticsdb", table_name="account")
creditcardaccount= glueContext.create_dynamic_frame.from_catalog(database="bnzanalyticsdb", table_name="creditcardaccount")
transaction = glueContext.create_dynamic_frame.from_catalog(database="bnzanalyticsdb", table_name="transaction")

customer.toDF().createOrReplaceTempView("customer")
account.toDF().createOrReplaceTempView("account")
creditcardaccount.toDF().createOrReplaceTempView("creditcardaccount")
transaction.toDF().createOrReplaceTempView("transaction")

# scenario 1 query 

scenario1_output_df=spark.sql("with account_temp as (
select customer_no,ltrim(account_no,'0') account_no, open_date, account_status, product_type_code 
from account where upper(account_status)='O' ) select acct.customer_no,account_no, product_type_code,
coalesce(cast(cc.open_date::text as date), acct.open_date)::date as open_date
from (select * from account_temp where product_type_code not in ('BUSS')) acct left outer join  credit_card_account cc
on acct.account_no = upper(cc.card_no) union all  select acct.customer_no,acc.account_no, product_type_code,
cast(cc.open_date::text as date) as open_date from (select customer_no,account_no,product_type_code from account_temp where product_type_code in ('BUSS')) acct 
inner join (select upper(card_no) card_no, open_date from credit_card_account where bill_acct='Y') cc
on account_no=card_no")

# Create staging path for wrangler for each table
wr_staging_path='s3://bnzanalyticsetljobs/Staging/Scenario1Output/'

# Load data to redshift 
try:
    # Get Redshift Connection Handle using Secret ID(ARN)
    conn = wr.redshift.connect(secret_id=args['secret_id'],dbname='bnzanalyticsdb')
    wr.redshift.copy(
        df=scenario1_output_df,
        path=wr_staging_path,
        con=conn,
        table='scenario_2_output',
        schema='public',
        mode='overwrite')
    conn.close()
except Exception as e:
    print(e)

