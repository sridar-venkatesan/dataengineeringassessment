from airflow import DAG, Dataset
from airflow.providers.amazon.aws.operators.redshift_sql import RedshiftSQLOperator
import pendulum

# Define datasets
customer_dataset = Dataset('redshift:bnzanalyticsdb:customer')
account_dataset = Dataset('redshift:bnzanalyticsdb:account')
creditcard_dataset = Dataset('redshift:bnzanalyticsdb:creditcard')
transaction_dataset = Dataset('redshift:bnzanalyticsdb:transaction')

default_args = {
    'owner': 'bnzanalytics',
    'email': ['sridar.venkatesan@bnz.com'],
    'email_on_failure': True
}

with DAG(
    dag_id='ard_refresh',
    start_date=pendulum.datetime(2022, 11, 23, tz="UTC"),
    template_searchpath='/home/airflow/airflow/dags/bnzassessment/sql/',
    #event driven scheduling based on airflow's dataset feature
    schedule=[customer_dataset,account_dataset,creditcard_dataset,transaction_dataset],
    default_args=default_args
) as dag1:

    RedshiftSQLOperator(dag=dag1,
                           redshift_conn_id='MONJUVI_SIT',
                           task_id='ard_refresh',
                           sql='ard.sql'
                  )

