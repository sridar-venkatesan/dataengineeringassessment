from airflow import DAG, Dataset
from airflow.providers.amazon.aws.operators.glue import AwsGlueJobOperator
import pendulum

glue_job_name = "ard_refresh"
glue_iam_role = "bnzanalyticss3role"
region_name = "us-east-1"

default_args = {
    'owner': 'bnzanalytics',
    'email': ['sridar.venkatesan@bnz.com'],
    'email_on_failure': True
}


# Define datasets
customer_dataset = Dataset('redshift:bnzanalyticsdb:customer')
account_dataset = Dataset('redshift:bnzanalyticsdb:account')
creditcard_dataset = Dataset('redshift:bnzanalyticsdb:creditcard')
transaction_dataset = Dataset('redshift:bnzanalyticsdb:transaction')

with DAG(dag_id = 'ardrefresh_using_glue', default_args = default_args,schedule=[customer_dataset,account_dataset,creditcard_dataset,transaction_dataset],start_date=pendulum.datetime(2022, 11, 23, tz="UTC")) as dag:

    glue_job_step = AwsGlueJobOperator(
        task_id = "Refresh_ard_using_glue",
        job_name = glue_job_name,
        job_desc = f"triggering glue job {glue_job_name}",
        region_name = region_name,
        iam_role_name = glue_iam_role,
        num_of_dpus = 1,
        dag = dag
        )
    glue_job_step
