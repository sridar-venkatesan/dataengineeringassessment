drop table if exists bnz_account;
create table bnz_account(customer_no integer, account_no varchar(4000),product_type_code varchar(1000),account_status varchar(10),open_date timestamp);

insert into bnz_account select 1232,'000650023XXXXXX1234','CCRD','O','2016-05-23 00:00:00';
insert into bnz_account select 1232,'000650023XXXXXX9876','CCRD','O','2018-06-20 00:00:00';
insert into bnz_account select 1232,'0002000004567899812','TRAN','O','2016-05-23 00:00:00';
insert into bnz_account select 1249,'0001000001234567801','TRAN','C','2005-08-12 00:00:00';
insert into bnz_account select 1249,'0001000001234567802','SAVG','O','2011-05-06 00:00:00';
insert into bnz_account select 1255,'000650010XXXXXX4569','BUSS','O','2014-02-20 00:00:00';
insert into bnz_account select 1255,'000650055XXXXXX2358','BUSS','O','2014-03-19 00:00:00';
insert into bnz_account select 1255,'0050000000012345600','HMLN','O','2017-02-02 00:00:00';
insert into bnz_account select 1268,'0050000000098765411','HMLN','O','2010-09-20 00:00:00';

