drop table if exists eligible_accounts ;
create table eligible_accounts as 
with account_temp as
(
-- fetch all Open accounts and trim leading 0's for data consistency
select customer_no,ltrim(account_no,'0') account_no, open_date, account_status, product_type_code 
from account 
where upper(account_status)='O'
)
select acct.customer_no,account_no, product_type_code,
coalesce(cast(cc.open_date::text as date), acct.open_date)::date as open_date
from 
(select * from account_temp where product_type_code not in ('BUSS')) acct 
left outer join 
credit_card_account cc
on acct.account_no = upper(cc.card_no)
union all 
select acct.customer_no,acct.account_no, product_type_code,
cast(cc.open_date::text as date) as open_date
from 
(select customer_no,account_no,product_type_code from account_temp where product_type_code in ('BUSS')) acct 
inner join 
(select upper(card_no) card_no, open_date from credit_card_account where bill_acct='Y') cc
on account_no=card_no
;

drop table bnzscenario2_output;
create table bnzscenario2_output as (
select distinct customer_no from 
eligible_accounts where  customer_no not in 
(select distinct customer_no from transactions
where date(trans_date)>=add_months(current_date,-3)));



drop table bnzscenario3_output;
create table bnzscenario3_output as (
select age_group,
(count( distinct case when product_type_code IN ('BUSS','CCRD') 
then customer_no else null end)/COUnt(distinct customer_no)::float)*100 || '%'
 from
(select customer_no, product_type_code  from 
eligible_accounts
group by 1,2
)acct
inner join 
(select customer_id,age, case when age between 18 and 29 then '18 - 29' 
            when age between 30 and 44 then '30 - 44'
            when age between 45 and 59 then '45 - 59'
            else '60+' end as age_group from customer group by 1,2)cust
on acct.customer_no=cust.customer_id
group by 1 
);

