drop table credit_card_account ;
create table credit_card_account(customer_no varchar(4000),card_no varchar(4000),open_date integer,bill_acct varchar(4000));
insert into credit_card_account select 1232,'650023xxxxxx1234','20011017','N';
insert into credit_card_account select 1232,'650023xxxxxx9876','20050105','N';
insert into credit_card_account select 1255,'650010xxxxxx4569','20001216','N';
insert into credit_card_account select 1255,'650055xxxxxx2358','20001207','Y';
