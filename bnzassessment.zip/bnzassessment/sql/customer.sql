drop table if exists bnz_customer;
create table bnz_customer(customer_no integer,age integer,start_date timestamp);
insert into bnz_customer select 1232,19,'2005-01-20 00:00:00';
insert into bnz_customer select 1249,76,'2002-05-23 00:00:00';
insert into bnz_customer select 1255,45,'1999-04-03 00:00:00';
insert into bnz_customer select 1268,32,'2008-07-16 00:00:00';
