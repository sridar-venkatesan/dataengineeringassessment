create table transactions(customer_no integer,account_no varchar(4000),trans_date timestamp,trans_type varchar(4000),
amount decimal(18,5));

insert into transactions select 1232,'000650023XXXXXX1234','2018-12-20 00:00:00','D',25.56;
insert into transactions select 1232,'000650023XXXXXX1234','2019-01-03 00:00:00','C',510.00;
insert into transactions select 1232,'000650023XXXXXX9876','2018-05-12 00:00:00','D',1250.00;
insert into transactions select 1232,'000650023XXXXXX9876','2019-03-19 00:00:00','D',49.45;
insert into transactions select 1255,'0050000000012345600','2018-09-12 00:00:00','D',1520.00;
insert into transactions select 1255,'0050000000012345600','2018-11-05 00:00:00','D',96.55;
insert into transactions select 1255,'0050000000012345600','2018-05-04 00:00:00','D',205.12;
	
